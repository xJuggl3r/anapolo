# Used for mocking the API responses. Requires data to work.
MOCK_API_RESPONSE = False
